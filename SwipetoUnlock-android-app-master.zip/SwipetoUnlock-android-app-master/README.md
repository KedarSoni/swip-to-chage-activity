# SwipetoUnlock-android-app
This repository contains a swipe to unlock android app which opens the new activity if you unlock the swipe button and design of the app is amazing and logic is also amazing


![O28O5jYrHJ4-HD](https://user-images.githubusercontent.com/64765400/96473557-a565e200-11e6-11eb-97a7-12859c3b472e.jpg)
